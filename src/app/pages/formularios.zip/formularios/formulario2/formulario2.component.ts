import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-formulario2',
  templateUrl: './formulario2.component.html'
})
export class Formulario2Component implements OnInit {

  // Mostramos los datos en los inputs y hacemos calculos entre ellos
  public formulario_2_Group: FormGroup;

  constructor() {}

  ngOnInit(): void {}

}
