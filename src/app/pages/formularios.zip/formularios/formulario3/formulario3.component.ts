import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulario3',
  templateUrl: './formulario3.component.html'
})
export class Formulario3Component implements OnInit {

    // Mostramos los datos en los inputs y salvamos los datos de los 3 formularios

  constructor() {}

  ngOnInit(): void {}

  save() {}

}
