import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-formulario1',
  templateUrl: './formulario1.component.html'
})
export class Formulario1Component implements OnInit {

  // Mostramos los datos en los inputs
  public formulario_1_Group: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

}
